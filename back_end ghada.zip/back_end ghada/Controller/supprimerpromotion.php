<?php
include "ajouterpromotion.php";

$promos = new promoC();

if (isset($_POST['idpromo'])) {
    $promos->supprimerpromo($_POST['idpromo']);
    header('location:../views/back/Modifierpromos.php');
} else {
    echo 'Erreur : try again';
    echo $_POST['idpromo'];
}
