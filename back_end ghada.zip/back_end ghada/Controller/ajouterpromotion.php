<?PHP
include "C://wamp64/www/thegofever/config.php";
require_once 'C://wamp64/www/thegofever/model/promos.php';

class promoC
{

    public function ajouterpromotion($promo)
    {
        $sql = "INSERT INTO promotion(nompromo,datedeb,datefin) 
			VALUES (:nompromo,:datedeb,:datefin)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);

            $query->execute([
                'nompromo' => $promo->getnompromo(),
                'datedeb' => $promo->getdatedeb(),
                'datefin' => $promo->getdatefin()
            ]);
        } catch (Exception $e) {
            echo 'Erreur: ' . $e->getMessage();
        }
    }

    public function afficherpromotion()
    {

        $sql = "SELECT * FROM promotion";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }



    function supprimerpromotion($id)
    {
        $sql = "DELETE FROM promotion WHERE idpromo = :idpromo";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':idpromo', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }



    function modifierpromotion($promotion, $id)
    {
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE promotion SET 
						nompromo = :nompromo, 
						datedeb= :datedeb,
                        datefin= :datefin
					WHERE idpromo = :idpromo'
            );
            $query->execute([
                'nompromo' => $promotion->getnompromo(),
                'datedeb' => $promotion->getdatedeb(), 
                'datefin' => $promotion->getdatefin(),        
                'idpromo' => $id
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }


    function recupererpromotion($id)
    {
        $sql = "SELECT * from promotion where idpromo=$id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute();

            $user = $query->fetch();
            return $user;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    function recherche($search_value)
        {
            $sql="SELECT * FROM promotion where  idpromo like '$search_value' or nompromo like '%$search_value%' ";
    
            //global $db;
            $db =Config::getConnexion();
    
            try{
                $result=$db->query($sql);
    
                return $result;
    
            }
            catch (Exception $e){
                die('Erreur: '.$e->getMessage());
            }
        }
        function sortv()
        {
            $sql = "SELECT * from promotion order by idpromo desc";
            $db = config::getConnexion();
            try {
                $liste = $db->query($sql);
                return $liste;
            } catch (Exception $e) {
                die('Erreur: ' . $e->getMessage());
            }
        }
}
