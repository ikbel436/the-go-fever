<?php

class promo
{
    private $nompromo;
    private $datedeb;
    private $datefin;





    public function getidpromo()
    {
        return $this->idpromo;
    }

    public function getnompromo()
    {
        return $this->nompromo;
    }
    public function getdatedeb()
    {
        return $this->datedeb;
    }
    public function getdatefin()
    {
        return $this->datefin;
    }

    public function setnompromo($nompromo)
    {
        $this->nompromo = $nompromo;
    }
    public function setdatedeb($datedeb)
    {
        $this->datedeb = $datedeb;
    }
    public function setdatefin($datefin)
    {
        $this->datefin = $datefin;
    }


    public function __construct($nompromo, $datedeb, $datefin)
    {
        $this->nompromo = $nompromo;
        $this->datedeb = $datedeb;
        $this->datefin = $datefin;
    }
}
